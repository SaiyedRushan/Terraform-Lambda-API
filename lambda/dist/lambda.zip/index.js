"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const one_liner_joke_1 = require("one-liner-joke");
exports.handler = () => {
    return Promise.resolve({
        statusCode: 200,
        body: JSON.stringify(one_liner_joke_1.getRandomJoke(), null, 2),
    });
};
